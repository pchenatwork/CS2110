/** Graphical user interface for the McDiver application
 */
package gui;

