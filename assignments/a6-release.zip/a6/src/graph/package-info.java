/** Graph algorithms and interfaces
 */
package graph;

