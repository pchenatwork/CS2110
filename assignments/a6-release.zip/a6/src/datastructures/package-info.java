/** Useful data structures for the McDiver application.
 */
package datastructures;

